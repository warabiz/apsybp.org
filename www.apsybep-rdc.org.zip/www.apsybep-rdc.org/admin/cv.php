<?php
include('db.php')
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>AFRICA GAMES</title>
    <link rel="icon" href="images/favicon.ico">
	<!-- Bootstrap Styles-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FontAwesome Styles-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- Custom Styles-->
    <link href="assets/css/custom-styles.css" rel="stylesheet" />
     <!-- Google Fonts-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">

                    <li>
                        <a  href="../index-2.php"><i class="fa fa-home"></i> Homepage</a>
                        <li><a><div id="google_translate_element"></div></a></li>
                    </li>
                    
					</ul>

            </div>

        </nav>
       
        <div id="page-wrapper" >
            <div id="page-inner">
			 <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Offre d'Emplois <small></small>
                        </h1>
                    </div>
                </div> 
                 
                                 
            <div class="row">
                
                <div class="col-md-5 col-sm-5">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            PERSONAL INFORMATION
                        </div>
                        <div class="panel-body">
						<form name="form" method="post">
                           
							  <div class="form-group">
                                            <label>Nom</label>
                                            <input name="nom" class="form-control" required>
                                            
                               </div>
                               <div class="form-group">
                                            <label>Prénom</label>
                                            <input name="prenom" class="form-control" required>
                                            
                               </div>
							   <div class="form-group">
                                            <label>Date de Naissance</label>
                                            <input name="naissance" type ="date" class="form-control">
                                            
                               </div>
                               <?php

								$countries = array("Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegowina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Congo", "Congo, the Democratic Republic of the", "Cook Islands", "Costa Rica", "Cote d'Ivoire", "Croatia (Hrvatska)", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands (Malvinas)", "Faroe Islands", "Fiji", "Finland", "France", "France Metropolitan", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard and Mc Donald Islands", "Holy See (Vatican City State)", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran (Islamic Republic of)", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, Democratic People's Republic of", "Korea, Republic of", "Kuwait", "Kyrgyzstan", "Lao, People's Democratic Republic", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libyan Arab Jamahiriya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia, The Former Yugoslav Republic of", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federated States of", "Moldova, Republic of", "Monaco", "Mongolia", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Seychelles", "Sierra Leone", "Singapore", "Slovakia (Slovak Republic)", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia and the South Sandwich Islands", "Spain", "Sri Lanka", "St. Helena", "St. Pierre and Miquelon", "Sudan", "Suriname", "Svalbard and Jan Mayen Islands", "Swaziland", "Sweden", "Switzerland", "Syrian Arab Republic", "Taiwan, Province of China", "Tajikistan", "Tanzania, United Republic of", "Thailand", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "United States Minor Outlying Islands", "Uruguay", "Uzbekistan", "Vanuatu", "Venezuela", "Vietnam", "Virgin Islands (British)", "Virgin Islands (U.S.)", "Wallis and Futuna Islands", "Western Sahara", "Yemen", "Yugoslavia", "Zambia", "Zimbabwe");

								?>
                               <div class="form-group">
                                            <label>Nationalité*</label>
                                            <select name="nationalite" class="form-control" required>
												<option value selected ></option>
                                                <?php
												foreach($countries as $key => $value):
												echo '<option value="'.$value.'">'.$value.'</option>'; //close your tags!!
												endforeach;
												?>
                                            </select>
								</div>
							   <div class="form-group">
                                            <label>Email</label>
                                            <input name="email" type="email" class="form-control" required>
                                            
                               </div>
                               <div class="form-group">
                                            <label>Numero de Telephone </label>
                                            <input name="telephone" type ="text" class="form-control" required>
                                            
                               </div>
                               <div class="form-group">
                                            <label>Langue Maternelle</label>
                                            <input name="lgmaternelle" class="form-control" required>
                                            
                                </div>
                            
							  
							   
                        </div>
                        
                    </div>
                </div>
                
                  
            <div class="row">
                <div class="col-md-6 col-sm-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            EDUCATION INFORMATION
                        </div>
                        <div class="form-group">
                                    <label>Formation scolaire / diplômes</label>
                                    <input name="diplome" class="form-control" required>
                                            
                        </div>
                        <div class="panel-body">
						<div class="form-group">
                                            <label>Connaissances informatiques  *</label>
                                            <select name="informatique"  class="form-control" required>
												<option value selected ></option>
                                                <option value="Bonnes connaissances">Bonnes connaissances</option>
                                                <option value="Intermédiaire">Intermédiaire</option>
												<option value="Faibles connaissances">Faibles connaissances</option>
												<option value="Aucune connaissance">Aucune connaissance</option>
                                            </select>
                        </div>
						<div class="form-group">
                                            <label>Traitement de texte </label>
                                            <select name="traitementtext"  class="form-control" required>
												<option value selected ></option>
                                                <option value="Bonnes connaissances">Bonnes connaissances</option>
                                                <option value="Intermédiaire">Intermédiaire</option>
												<option value="Faibles connaissances">Faibles connaissances</option>
												<option value="Aucune connaissance">Aucune connaissance</option>
                                            </select>
                        </div>
                        <div class="form-group">
                                            <label>Connaissances linguistiques Français*</label>
                                            <select name="français"  class="form-control" required>
												<option value selected ></option>
                                                <option value="Langue maternelle">Langue maternelle</option>
                                                <option value="Bonnes connaissances">Bonnes connaissances</option>
                                                <option value="Intermédiaire">Intermédiaire</option>
												<option value="Faibles connaissances">Faibles connaissances</option>
												<option value="Aucune connaissance">Aucune connaissance</option>
                                            </select>
                        </div>
                        <div class="form-group">
                                            <label>Connaissances linguistiques Anglais*</label>
                                            <select name="anglais"  class="form-control" required>
												<option value selected ></option>
                                                <option value="Langue maternelle">Langue maternelle</option>
                                                <option value="Bonnes connaissances">Bonnes connaissances</option>
                                                <option value="Intermédiaire">Intermédiaire</option>
												<option value="Faibles connaissances">Faibles connaissances</option>
												<option value="Aucune connaissance">Aucune connaissance</option>
                                            </select>
                        </div>
                        <div class="form-group">
                                            <label>Connaissances linguistiques Portugais*</label>
                                            <select name="portugais"  class="form-control" required>
												<option value selected ></option>
                                                <option value="Langue maternelle">Langue maternelle</option>
                                                <option value="Bonnes connaissances">Bonnes connaissances</option>
                                                <option value="Intermédiaire">Intermédiaire</option>
												<option value="Faibles connaissances">Faibles connaissances</option>
												<option value="Aucune connaissance">Aucune connaissance</option>
                                            </select>
                        </div>
                        <div class="form-group">
                                            <label>Connaissances linguistiques Autres*</label>
                                            <input name="autres" class="form-control" required>
                                            
                                </div>
								
						
                       </div>
                        
                    </div>
                </div>
				
				
                <div class="col-md-12 col-sm-12">
                    <div class="well">
                        <h4>VERIFICATION HUMAINE</h4>
                        <p>Copié et coller se code en bas <?php $Random_code=rand(); echo$Random_code; ?> </p><br />
						<p>Entrer le code random ici<br /></p>
							<input  type="text" name="code1" title="random code" />
							<input type="hidden" name="code" value="<?php echo $Random_code; ?>" />
						<input type="submit" name="submit" class="btn btn-primary">
						<?php
							if(isset($_POST['submit']))
							{
							$code1=$_POST['code1'];
							$code=$_POST['code']; 
							if($code1!="$code")
							{
							$msg="Invalide code"; 
							}
							else
							{
							
                                    $con=mysqli_connect("localhost","root","","africagames");
									$check="SELECT * FROM cv WHERE email = '$_POST[email]'";
									$rs = mysqli_query($con,$check);
									$data = mysqli_fetch_array($rs, MYSQLI_NUM);
									if($data[0] > 1) {
										echo "<script type='text/javascript'> alert('User Already in Exists')</script>";
										
									}

									else
									{
										$new ="Not Conform";
										$newUser="INSERT INTO `cv` (`nom`, `prenom`, `naissance`, `nationalite`, `email`, `telephone`, `lgmaternelle`, `diplome`, `informatique`, `traitementtex`, `français`, `anglais`, `portugais`, `autres`) VALUES ('$_POST[nom]','$_POST[prenom]','$_POST[naissance]','$_POST[nationalite]','$_POST[email]','$_POST[telephone]','$_POST[lgmaternelle]','$_POST[diplome]','$_POST[informatique]','$_POST[traitementtext]','$_POST[français]','$_POST[anglais]','$_POST[portugais]','('$_POST[autres]))";
										if (mysqli_query($con,$newUser))
										{
											echo "<script type='text/javascript'> alert('Votre CV a été envoyer avec succés')</script>";
											
										}
										else
										{
											echo "<script type='text/javascript'> alert('Erreur d'insertion a la base de donnée')</script>";
											
										}
									}

							$msg="Your code is correct";
							}
							}
							?>
						</form>
							
                    </div>
                </div>
            </div>
           
                
                </div>
                    
            
				
					</div>
			 <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER   -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
    <!-- Google analytics-->
		<script>(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,'script','../www.google-analytics.com/analytics.js','ga');ga('create', 'UA-81807682-1', 'auto');ga('send', 'pageview');</script>
		
		<script>
			function googleTranslateElementInit() {
				  new google.translate.TranslateElement({
					pageLanguage: 'pt',
					includedLanguages: 'ca,da,de,el,en,es,fr,it,ja,ko,nl,pl,pt,ru,sv,tl',
					layout: google.translate.TranslateElement.InlineLayout.SIMPLE
				  }, 'google_translate_element');
				};
		</script>
		<style type="text/css">
		  div#google_translate_element div.goog-te-gadget-simple{background-color: transparent; border: transparent;}
		  div#google_translate_element div.goog-te-gadget-simple a.goog-te-menu-value span{color:#555}
		</style>
		<script type="text/javascript" src="../translate.google.com/translate_a/elementa0d8.html?cb=googleTranslateElementInit"></script>
		<script>
			$(document).ready(function() {
				populateNationality("nacionalidade");
			});
		</script>
   
</body>
</html>
