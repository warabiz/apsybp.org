<?php
$con = mysqli_connect("localhost","root","","africagames") or die(mysql_error());

?>