<?php

include ('db.php');

$id=$_GET['eid'];
if($id=="")
{
echo '<script>alert("Sorry ! Wrong Entry") </script>' ;
		header("Location: profit.php");


}

else{
$view="DELETE FROM `partenaire` WHERE id ='$id' ";

	if($re = mysqli_query($con,$view))
	{
		echo '<script>alert("Partenaire Suprimer") </script>' ;
		header("Location: profit.php");
	}


}







?>