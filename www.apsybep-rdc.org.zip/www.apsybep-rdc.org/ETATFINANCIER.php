<?php	
$heure=date('H');
	$min=date('i');
	Echo"Heure:".$heure."h".$min;
//INSERT INTO `trecettescaisse` (`idcodere`, `detailrece`, `personnel`, `montant`, `daterece`) VALUES (NULL, 'versement revendeur', 'amisi care', '340', NOW());
try
{
	//$match='West Ham-Leeds';
    //$pdo_options[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;
    //$bdd = new PDO('mysql:host=hoster;dbname=cabov1354206_1kertz', 'root', '', $pdo_options);
     
     include('maconnexion.php');
    // On recupere tout le contenu de la table Client
$reponse = $dbh->query("SELECT * FROM RECETTECAISSE,DEPENSESTOTAL,VERSEMENTTOTAL,totalventeticke,tnombretickettotal");

  echo"<table align='center' border=2>";
  echo"<tr>";
  echo"<th>Total Recette Caisse</th>";
   echo"<th>total Depense Effectuées</th>";
     echo"<th>Versement-vendeur</th>";
	 echo"<th>Solde en Caisse</th>";
	  echo"<th>Solde en $</th>";
	   echo"<th>Montant vente</th>";
	   echo"<th>Nbre/Ticket Vendu</th>";
	 Echo"</tr>";
  

// On affiche le resultat
while($donnees = $reponse->fetch())
{
					
	//echo"$donnees[codeticket]<br>";
	$recette=$donnees['recettecaisse'];
	$depense=$donnees['SUM(montant)'];
	$versement=$donnees['SUM(versement)'];
	$totalvente=$donnees['Totalventeticke'];
	$totaltiket=$donnees['totaltickevendu'];
	
	$olde=$recette-$depense;
	$devise=$olde/2000;
	//echo"le total:".$total;
	
	//ECHO"HEURE:".$heure."MIN:".$min;
	
	///echo"".$BONUS;
	echo"<tr><td>".$recette."FC</td>";
	echo"<td>".$depense."FC</td>";
	echo"<td>".$versement."FC</td>";
	echo"<td>".$olde."FC</td>";
	echo"<td>".$devise."$</td>";
	echo"<td>".$totalvente."FC</td>";
	echo"<td>".$totaltiket."Tickets </td>";
                  
				  
//echo "<U><B>CG-IDTIC:$donnees[BONUS]</B></U>";
//echo"<p><B>=====================</B></p>";


 echo"";
			echo" ";
}

echo "</tr></table>";
 echo"";
$reponse->closeCursor();
}
catch(Exception $e)
{
    die('Erreur : '.$e->getMessage());
}
ECHO"";

?>