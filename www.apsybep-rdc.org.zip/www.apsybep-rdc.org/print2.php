
<!------------------------ Below is sample response file program in PHP (response.php) --------------------------->
<script language="javascript" type="text/javascript">
    window.print();
	
</script>

<?php
try
{
	echo"bonjour ";
    
	//$pdo_options[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;
    //$bdd = new PDO('mysql:host=hoster;dbname=cabov1354206_1kertz', 'root', '', $pdo_options);
     
     include('maconnexion.php');
    // On recupere tout le contenu de la table Client
$reponse = $dbh->query("SELECT * FROM tbonus");
  //echo"<h6>Congo Games</h6>";
 // echo"";

// On affiche le resultat
while($donnees = $reponse->fetch())
{
	//echo"$donnees[codeticket]<br>";
	$BONUS=$donnees['BONUS'];
//echo "<U><B>CG-IDTIC:$donnees[BONUS]</B></U>";
//echo"<p><B>=====================</B></p>";
}
echo "";
 echo"";
$reponse->closeCursor();
}
catch(Exception $e)
{
    die('Erreur : '.$e->getMessage());
}
ECHO"";
?>
<?php
try
{
    //$pdo_options[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;
    //$bdd = new PDO('mysql:host=hoster;dbname=cabov1354206_1kertz', 'root', '', $pdo_options);
     
     include('maconnexion.php');
    // On recupere tout le contenu de la table Client
$reponse = $dbh->query("SELECT * FROM matchsparie where CODEP=$_POST[ID]");
  //echo"<h6>Congo Games</h6>";
 // echo"";

// On affiche le resultat
if($donnees = $reponse->fetch())
{
	//echo"$donnees[codeticket]<br>";
	$totalmach=$donnees['TOTALMATCH'];
	echo"<h6 size=3 >total match Paries:".$totalmach."</h6>";
//echo "<U><B>CG-IDTIC:$donnees[BONUS]</B></U>";
//echo"<p><B>=====================</B></p>";
}
echo "";
 echo"";
$reponse->closeCursor();
}
catch(Exception $e)
{
    die('Erreur : '.$e->getMessage());
}
ECHO"";
?>

<?php

try
{
    //$pdo_options[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;
    //$bdd = new PDO('mysql:host=hoster;dbname=cabov1354206_1kertz', 'root', '', $pdo_options);
     
     include('maconnexion.php');
    // On recupere tout le contenu de la table Client
$reponse = $dbh->query("SELECT * FROM ticketactuel where codeticket=$_POST[ID]");
  //echo"<h6>Congo Games</h6>";
 // echo"";
 echo"<h6><a href='plusdesmatch.php'>Congo Games</a></h6>";
  echo"";
  echo"";
  echo"<p><font size='2pt'style='line-height:10px;'>Congo Games</font></p>";
  echo"<p><font size='2pt'style='line-height:10px;'>Na 500FC ya pamba Somba Ndako Na paris</font></p>";
  echo"<font size='2pt'style='line-height:10px;'><B>---------------</B></font></p>";
  //echo"<img src='logos/logovrai.jpg' alt='' width='10%' height='20%' class='img-fluid'>";
// On affiche le resultat
if($donnees = $reponse->fetch())
{
	//echo"$donnees[codeticket]<br>";
	
echo "<U><B>CG-IDTIC".$donnees['codeticket']."</B></U>";
$id=$donnees['codeticket'];
//echo"<p><B>=====================</B></p>";
}
echo "";
 echo"";
$reponse->closeCursor();
}
catch(Exception $e)
{
    die('Erreur : '.$e->getMessage());
}
ECHO"";
?>

 <?php
try
{
    //$pdo_options[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;
    //$bdd = new PDO('mysql:host=hoster;dbname=cabov1354206_1kertz', 'root', '', $pdo_options);
     
     include('maconnexion.php');
    // On recupere tout le contenu de la table Client
$reponse = $dbh->query("SELECT * FROM ticketactuel where codeticket=$_POST[ID]");
 echo"";
                   // echo"<th></th>";
					//echo"<th></th></tr>";
// On affiche le resultat
while($donnees = $reponse->fetch())
{
	
	//echo"$donnees[codeticket]<br>";
//echo "<BR><strong> $donnees[competition]</strong>&nbsp;&nbsp$donnees[date]:<strong>&nbsp;&nbsp $donnees[heure]</strong>";
//echo"<strong>&nbsp;&nbsp $donnees[cote]</strong>";
//echo"";``
echo"<p><font size='2pt'style='line-height:10px;'>".$donnees['codematch']."-".$donnees['heure']." ".$donnees['date']."";
echo"<br size=3>".$donnees['competition']." ".$donnees['PROB']."<B>:</B>".$donnees['cote']."<br>";
 echo"-----------------------</font>";
}
$reponse->closeCursor();
}
catch(Exception $e)
{
    die('Erreur : '.$e->getMessage());
}
ECHO"";
?>

<?php
try
{
    //$pdo_options[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;
    //$bdd = new PDO('mysql:host=hoster;dbname=cabov1354206_1kertz', 'root', '', $pdo_options);
     
     include('maconnexion.php');
    // On recupere tout le contenu de la table Client
$reponse = $dbh->query("SELECT * FROM TICKEMV2 WHERE codeticket=$_POST[ID]");
  //echo"<h6>Congo Games</h6>";
 // echo"";
  echo"</br>";
  //echo"<img src='logos/logovrai.jpg' alt='' width='10%' height='20%' class='img-fluid'>";
// On affiche le resultat
while($donnees = $reponse->fetch())
{
	//echo"$donnees[codeticket]<br>";
	
echo "<p><font size='2pt'style='line-height:10px;'><B>MISE:".$donnees['MISE']."FC</B></BR><B>Gains:".$donnees['GAINSCLIENT']."FC</B></font></p>";
//ECHO"<B>BONUS".$BONUS;
 $Gains=$donnees['GAINSCLIENT'];
 $totalmach;
$Mamise=$donnees['MISE'];
$BONUS;
$bonuscal;
if($totalmach<5 and $Mamise<=1000)
{
	$bonuscal=0;
}
else{
	$bonuscal=$BONUS;
}
echo"<p><font size='2pt'style='line-height:10px;'>nbr:".$totalmach."misie:".$Mamise."</font></p>";
	 $bonus =$Gains*$bonuscal/100;
	echo"BONUS AMT:".$bonus;
	$TOTAL=$Gains+$bonus;
	//$TOT=$TOTAL-0.1000000000;
	ECHO"<p><font size='2pt'style='line-height:10px;'><B><TOTAL AMT:".$TOTAL."</B></font></p>";
	//ECHO"".$TOT;
	$TOTAL=$Gains+$bonus;
	//$TOT=$TOTAL-0.1000000000;
	ECHO"<p><font size='2pt'style='line-height:10px;'>TOTAL AMT:".$TOTAL."</B></font></p>";
echo"<p><B>-----------</B></p>";
echo"<p><font size='2pt'style='line-height:10px;'>CG-IDTIC".$id."</font></p>";
echo"<img src='codebare.png' width=5% height=10% alt=0>";

}
echo "";
 echo"";
$reponse->closeCursor();
}
catch(Exception $e)
{
    die('Erreur : '.$e->getMessage());
}
ECHO"";
//header('location:plusdesmatch.php');
?>
