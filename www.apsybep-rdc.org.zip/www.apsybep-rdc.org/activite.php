<!DOCTYPE html>
<html lang="fr">
	
<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Hotel VIP Praia | Want to visit paradise? Cape Verde is your destination, so come visit our islands. Situated in the coust of Africa, come on enjoy the sun and the fun! Travel to the perfect destination of tourism. Booking in hotels are always available.">
        <meta name="keywords" content="Cabo Verde, Visit Cabo Verde, Tourism Cabo Verde, Summer, Sun, Santiago Island, Beach, Kebra Kanela, Hotel VIP Praia, Excursions, Confort, Peace of Mind">
        <meta name="author" content="Prime Consulting">
        <title>ASSOCIATION DES PSYCHOLOGUES POUR LE BIEN ETRE DE LA POPULATION EN RDC</title>
		<link rel="icon" href="logjacque.png">
		<link href=https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic|Playfair+Display:400,400italic,700,700italic,900,900italic rel=stylesheet type=text/css>
		<!-- Bootstrap -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/font-awesome.min.css" rel="stylesheet">

		<link href="css/owl.carousel.css" rel="stylesheet">
		<link href="css/owl.theme.css" rel="stylesheet">
		<link href="css/owl.transitions.css" rel="stylesheet">
		<link href="css/cs-select.css" rel="stylesheet">
		<link href="css/bootstrap-datepicker3.min.css" rel="stylesheet">
		<link href="css/freepik.hotels.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">

		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesnt work if you view the page via file:// -->
		<!--[if lt IE 9]>
		<script src="js/html5shiv.min.js"></script>
		<script src="js/respond.min.js"></script>
		<![endif]-->
		<script src="js/modernizr.custom.min.js"></script>
		
	</head>
	<body onunload="saveData( )">
		<div class="preloader"></div>
		<header class="header transp sticky"> <!-- available class for header: .sticky .center-content .transp -->
			<nav class="navbar navbar-inverse" style="background-color: rgba(255, 255, 255, 0.9);">
				<div class="container">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="#"><img src="logjacque.png" alt="logo" style="height: 90px"></a>
					</div>
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav navbar-right">
						<li  class="active"><a href="index.php">Acuiel</a></li>
							<li  class="active"><a href="objectif.php">Objectif</a></li>
							<li><a href="activite.php">Activites</a></li>
							<li><a href="mission.php">Mission</a></li>
							<li><a href="realisation.php">Projets Realises</a></li>
							<li><a href="encour.php">Projets Encours</a></li>
							<li><a href="paris.php">Formation</a></li>
							<li><a href="about.php">Contacts</a></li>
							<!--<li><a href="promotions.html">Promo��es</a></li>-->
							<li><a href="domaine.php">Domaine</a></li>
							<li><a href="enplois.php">Offres demplois</a></li>
							<li><a href="parteneriat.php">Parteneriat</a></li>
							<li><a href="contact.php">Contacts</a></li>
							<li><a><div id="google_translate_element"></div></a></li>
						</ul>
					</div><!-- /.navbar-collapse -->
				</div><!-- /.container-fluid -->
			</nav>
		</header>


		<div id="mega-slider" class="carousel slide " data-ride="carousel">

			<!-- Wrapper for slides -->
			<div class="carousel-inner" role="listbox">
                <div class="item active beactive">
                	<img src="img/slides/CONSULT1.jpg" alt="slide1">
					<div class="carousel-caption">
						<!--<img src="images/stars.png" alt="">-->
						<!--<h2>Bem-vindo ao Hotel <span style="color: orange;">VipPraia</span></h2>-->
						<!--<img src="img/santiago.png" class="shade" style="width:120px">-->
					</div>
				</div>
				</br></br>
				<div class="item">
					<img src="img/slides/CONSULT2.jpg" alt="slide2">
					<div class="carousel-caption">
						<!--<img src="images/stars.png" alt="">-->
						<!--<h2>Visit Praia</h2>-->
						<!--<img src="img/santiago.png" class="shade" style="width:120px">-->
					</div>
				</div>
				<div class="item">
					<img src="img/slides/CONSULT3.jpg" alt="slide3">
					<div class="carousel-caption">
						<!--<img src="images/stars.png" alt="">-->
						<!-- <h2>Visit Praia</h2>
						<img src="img/santiago.png" class="shade" style="width:120px"> -->
					</div>
				</div>
				<div class="item">
					<img src="img/slides/CONSULT4.jpg" alt="slide3">
					<div class="carousel-caption">
						<!--<img src="images/stars.png" alt="">-->
				
					</div>
				</div>
			</div>


		<div class="mg-about parallax">
			<div class="container">
				<div class="row">
				<P>
					<h2 class="mg-sec-left-title">VI.	Activites a mener</h2>

1.	Accompagnement et encadrement des sujets ayant perdu l�equilibre mental et qui sont en deficit psychologique ;
2.	Accompagnement et encadrement des personnes victimes de la violence basee sur le genre ;
3.	Cliniques mobiles d�intervention dans les structures sanitaires et etablissements scolaires;
4.	Prise en charge psychotherapeutique des couples et jeunes en detresse ;
5.	 Accompagnement de personnes vivantes avec des maladies chroniques (VIH/SIDA, Diab�te,�);
6.	Mener des activites aupr�s des Etats, Organisations Etatiques et Organisations internationales bailleurs des fonds pour la mobilisation des ressources financi�res necessaires � l�execution des projets et des activites de APSYBEP-RDC ;
7.	 Initier les activites qui favorisent la cohabitation pacifique des ethnies et le developpement de la culture de la paix ;
8.	Intervention dans le domaine de coaching en developpement personnel ;
9.	 Promotion de  l�unite de la jeunesse, changement de mentalite ainsi que le genre dans le monde entier ;
10.	Contribution � la lutte contre la pauvrete et ch�mage � travers lentrepreneuriat ;
11.	 Encouragement des femmes et filles du monde entier dans la lutte contre la dependance financi�re et loisivete ;
12.	Reinsertion familiale des enfants vivants dans la rue ;
13.	  Encadrement des femmes et filles vulnerables � lauto prise en charge � travers les activites generatrices des revenus ;
14.	 Encadrement des etudiants stagiaires dans des recherches scientifiques;
15.	 Contribution � l�education sexuelle et reproductive ;
16.	Planning familial (baby-spacing) ;
17.	Orientation et encadrement des enfants qui ont des comportements antisociaux ;
18.	Mener les etudes evaluatives periodiques des activites de APSYBEP-RDC ;
19.	 Faire les plaidoyers.


</p>
</div>
					<div class="col-md-6">
					<div class="mg-gallery-container">
						<li><img src="img/slides/CONSULT4.jpg" alt="Recepcao"></li>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="mg-about parallax">
			<div class="container">
				<div class="row">
					<div class="col-md-6">
						
					</div>
					<div class="col-md-6">
					<div class="mg-gallery-container">
						<li><img src="logjacque.png" width=330 height=320 alt="Recepcao" ></li>
						</div>
					</div>
				</div>
			</div>
		</div>


		<div class="mg-about parallax">
			<div class="container">
				<div class="row">
					<div class="col-md-6">
						<h2 class="mg-sec-left-title">III.	MISSION</h2>
						<p>APSYBEP-RDC a pour mission de contribuer � la mise en �uvre des programmes humanitaires pour repondre aux urgences generees par les conflits, les epidemies, les catastrophes naturelles et la pauvrete structurelle, � travers la remise de l�assistance, l�accompagnement psychologique et le renforcement des communautes beneficiaires 
						pour assurer leur bien-�tre et le developpement durable.
						
</p>
</div>
<div class="col-md-6">
						<h2 class="mg-sec-left-title">IV.	Vision</h2>

						<p>L�APSYBEP-RDC a une vision  de promouvoir une  region meilleure o� r�gne la justice, les valeurs humaines et le bien �tre mental.

						<h2 class="mg-sec-left-title">V.	Domaines dintervention : </h2>
1.	Sante;
2.	Education;
3.	Insertion socio-professionnelle;
4.	Bonne gouvernance
5.	Droits humains;
6.	Securite alimentaire ;
7.	Developpement institutionnel 
8.	Protection de l�enfant ;
9.	Recherche scientifique

<h2 class="mg-sec-left-title">VI.	Activites � mener</h2>

1.	Accompagnement et encadrement des sujets ayant perdu l�equilibre mental et qui sont en deficit psychologique ;
2.	Accompagnement et encadrement des personnes victimes de la violence basee sur le genre ;
3.	Cliniques mobiles d�intervention dans les structures sanitaires et etablissements scolaires;
4.	Prise en charge psychotherapeutique des couples et jeunes en detresse ;
5.	 Accompagnement de personnes vivantes avec des maladies chroniques (VIH/SIDA, Diab�te,�);
6.	Mener des activites aupr�s des Etats, Organisations Etatiques et Organisations internationales bailleurs des fonds pour la mobilisation des ressources financi�res necessaires � l�execution des projets et des activites de APSYBEP-RDC ;
7.	 Initier les activites qui favorisent la cohabitation pacifique des ethnies et le developpement de la culture de la paix ;
8.	Intervention dans le domaine de coaching en developpement personnel ;
9.	 Promotion de  l�unite de la jeunesse, changement de mentalite ainsi que le genre dans le monde entier ;
10.	Contribution � la lutte contre la pauvrete et ch�mage � travers lentrepreneuriat ;
11.	 Encouragement des femmes et filles du monde entier dans la lutte contre la dependance financi�re et loisivete ;
12.	Reinsertion familiale des enfants vivants dans la rue ;
13.	  Encadrement des femmes et filles vulnerables � lauto prise en charge � travers les activites generatrices des revenus ;
14.	 Encadrement des etudiants stagiaires dans des recherches scientifiques;
15.	 Contribution � l�education sexuelle et reproductive ;
16.	Planning familial (baby-spacing) ;
17.	Orientation et encadrement des enfants qui ont des comportements antisociaux ;
18.	Mener les etudes evaluatives periodiques des activites de APSYBEP-RDC ;
19.	 Faire les plaidoyers.


</p>
</div>
<div class="carousel-inner" role="listbox">
                <div class="item active beactive">
                	<img src="img/slides/CONSULT1.jpg" alt="slide1">
					<div class="carousel-caption">
						<!--<img src="images/stars.png" alt="">-->
						<!--<h2>Bem-vindo ao Hotel <span style="color: orange;">VipPraia</span></h2>-->
						<!--<img src="img/santiago.png" class="shade" style="width:120px">-->
					</div>
					</div>
					<div class="col-md-6">
					<div class="mg-gallery-container">
						<li><img src="images/COSULTATIONPRO.jpg" width=330 height=320 alt="Recepcao"></li>
						</div>
					</div>
				</div>
			</div>
		</div>
		<footer class="mg-footer">
			<div class="mg-footer-widget" style="padding-top: 10px; padding-bottom: 10px;">
				<div class="container" style="margin-right: 0px;">
					<div class="row">
						<div class="col-md-4 col-md-offset-2 visible-lg">
							<div class="widget" style="margin-bottom: 0px;">
								<address style="margin-bottom: 0px;">
									<strong>APSYBEP-RDC</strong><br>
								Si�ge social : GOMA, PROVINCE DU  N-K EN RDC
Adresse physique : Q. Majengo, Av. Bwisha N�23 en diagonale de la maison blanche	
Contact : +243977 553 293, +243994 081 522
E-mail : ass.psybep.goma17@gmail.com 
									 <br>
									
								</address>
								
							</div>
						</div>
						<div class="col-md-4 visible-lg">
							<div class="widget" style="margin-bottom: 0px;">
								<strong>Contacts</strong><br>
								<p style="margin-bottom: 0px;">
									Telefone: (+243) 972 33 85 05<br>
									Fax: (+243) 810 22 01 01<br>
									Email: info@warabiz.com
								</p>
								
							</div>
						</div>
						<!--
						<div class="col-md-4 visible-lg">
							<div class="widget" style="margin-bottom: 0px;">
								<strong>E-mail</strong><br>
								<p style="margin-bottom: 0px;">
									<a href="mailto:#">booking@hotelvippraia.cv</a>
								</p>
							</div>
						</div>
						-->
						<div class="col-md-6 hidden-lg" style="width: 250px; margin-left: 70px;">
							<div class="widget" style="margin-bottom: 0px;">
								<address style="margin-bottom: 0px;">
									<strong>APSYBEP-RDC</strong><br>
									Si�ge social : GOMA, PROVINCE DU  N-K EN RDC
Adresse physique : Q. Majengo, Av. Bwisha N�23 en diagonale de la maison blanche
<br>
									
								</address>
							</div>
						</div>
						<div class="col-md-6 hidden-lg" style="width: 250px; margin-left: 70px;">
							<div class="widget" style="margin-bottom: 0px;">
								<strong>Contactos</strong><br>
								<p style="margin-bottom: 0px;">
									Contact : +243977 553 293, +243994 081 522<br>
E-mail : ass.psybep.goma17@gmail.com 
									<!-- <a href="mailto:#">booking@hotelvippraia.cv</a> -->
								</p>
								
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="mg-copyright">
				<div class="container">
					<div class="row">
						<div class="col-md-12" style="text-align: center;">
						<a href="https://guineeconnexion.net" target="_blank">WaraBiz Sante by Rdc Connexion � 2021</a>
						</div>
					</div>
				</div>
			</div>
		</footer>

		<!-- jQuery (necessary for Bootstraps JavaScript plugins) -->
		<script src="js/jquery.min.js"></script>
		<!-- Include all compiled plugins (below), or include individual files as needed -->
		<script src="js/bootstrap.min.js"></script>
		<script src="js/owl.carousel.min.js"></script>
		<script src="js/jssor.slider.mini.js"></script>
		<script src="js/classie.js"></script>
		<script src="js/selectFx.js"></script>
		<script src="js/bootstrap-datepicker.min.js"></script>
		<script src="js/starrr.min.js"></script>
		<script src="js/nivo-lightbox.min.js"></script>
		<script src="js/jquery.shuffle.min.js"></script>
		<!--<script src="js/gmaps.min.js"></script>-->
		<script src="js/jquery.parallax-1.1.3.js"></script>
		<script src="js/script.js"></script>
		
		<!-- Google analytics-->
		<script>(function(i,s,o,g,r,a,m){i[GoogleAnalyticsObject]=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,script,../www.google-analytics.com/analytics.js,ga);ga(create, UA-81807682-1, auto);ga(send, pageview);</script>
		
		<script>
			function googleTranslateElementInit() {
				  new google.translate.TranslateElement({
					pageLanguage: pt,
					includedLanguages: ca,da,de,el,en,es,fr,it,ja,ko,nl,pl,pt,ru,sv,tl,
					layout: google.translate.TranslateElement.InlineLayout.SIMPLE
				  }, google_translate_element);
				};
		</script>
		<style type="text/css">
		  div#google_translate_element div.goog-te-gadget-simple{background-color: transparent; border: transparent;}
		  div#google_translate_element div.goog-te-gadget-simple a.goog-te-menu-value span{color:#555}
		</style>
		<script type="text/javascript" src="../translate.google.com/translate_a/elementa0d8.html?cb=googleTranslateElementInit"></script>
		
		<!-- tripadvisor -->
		<script src="https://www.jscache.com/wejs?wtype=selfserveprop&amp;uniq=960&amp;locationId=7315140&amp;lang=en_US&amp;rating=true&amp;nreviews=5&amp;writereviewlink=true&amp;popIdx=false&amp;iswide=false&amp;border=false&amp;display_version=2"></script>

		<script>
		  /* Send sotres the check-in and Check-out values to be use for autocompleting the reservation form on another page*/
		  function store(){
			if (typeof(Storage) !== "undefined") {
				if(document.theform.widget_date.value != "" && document.theform.widget_date_to.value != "") {
					sessionStorage.setItem("check_in_session", document.theform.widget_date.value);
					sessionStorage.setItem("check_out_session", document.theform.widget_date_to.value);
				}
				else {
					if(document.theform_s.widget_date_s.value != "" && document.theform_s.widget_date_to_s.value != "") {
						sessionStorage.setItem("check_in_session", document.theform_s.widget_date_s.value);
						sessionStorage.setItem("check_out_session", document.theform_s.widget_date_to_s.value);
					}
				}
			} else {
				alert("Sorry! No Web Storage support..")
			}
		  };
		</script>
		
	</body>


<!-- Mirrored from hotelvippraia.cv/index.html by HTTrack Website Copier/3.x [XR&CO2014], Thu, 03 Sep 2020 17:07:30 GMT -->
</html>