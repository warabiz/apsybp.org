<?php
 $i;
$nombre;
$nombre=200;
for ($i = 0; $i < $nombre  - 1; $i++)
                {
                echo"bonjour<br>";
                }
?>