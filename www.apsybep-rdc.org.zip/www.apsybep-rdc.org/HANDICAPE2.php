<?php
INCLUDE('TOTALRESULTAT.php');
include('verificationbeneficier.php');
include('verificationpanier.php');
if(isset($_POST['VALIDERRESULTAT']))
{
try
{
	$match2=$verifier2;
	ECHO"COMPETITIO:".$match2;
    //$pdo_options[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;
    //$bdd = new PDO('mysql:host=hoster;dbname=cabov1354206_1kertz', 'root', '', $pdo_options);
     
     include('maconnexion.php');
    // On recupere tout le contenu de la table Client
$reponse = $dbh->query("SELECT * FROM panier where competitionP='$match' and parp='$Scorehandicap2'");
  echo"<h1>resutat Probabilité Phase HANDICAP2 est $Scorehandicap2</h1>";
  echo" <div class='card-body'>
                <table id='example1' class='table table-bordered table-striped'>
                  <thead>
                  <tr>
                    <th>Match des Competitions</th>
					 <th style='color:red'>code client</th>
					 <th>gains</th>
					  <th>code parie</th>
                    <th>Points</th>
                   
                    <th>Activation de Match</th>
                    <th>x</th>
                  </tr>
                  </thead>";

// On affiche le resultat
while($donnees = $reponse->fetch())
{
	//echo"$donnees[codeticket]<br>";
	$Match=$donnees['competitionP'];
	$codeparie=$donnees['parp'];
	$gains=$donnees['GAINS'];
	$datemate=$donnees['CODEP'];
	$activation=$donnees['cotep'];
	$heure=date('H');
	$min=date('i');
	if($verifier==$verifier2)
{
	echo'<script>alert("ce match existe deja");</script>';
}
else{
	INCLUDE('INSERERGAINSCLIENT.php');
}
	//ECHO"HEURE:".$heure."MIN:".$min;
	
	///echo"".$BONUS;
	echo"<tbody>
                  <tr>
				 
<td>$Match</td> <td>$codeparie</td>";
					echo"";
	
		 echo"<td>$gains</td>";
	
                  
				  
//echo "<U><B>CG-IDTIC:$donnees[BONUS]</B></U>";
//echo"<p><B>=====================</B></p>";


 echo"<td>$heurematch:$minutematch</td><td>$datemate</td>";
 ECHO"<TD><li class='nav-item'>
              <a class='nav-link anebled' href='login.php' style='color:blue'>Modifier Point</a>
            </li><li class='nav-item'>
              <a class='nav-link anebled' href='login.php' style='color:blue'>Suprimer</a>
			  <a class='nav-link anebled' href='login.php' style='color:blue'>Ajouter</a>
            </li></TD>";
			if($activation==1)
			{
			echo"
         <td> $activation Match <B style='color:green'>Activé</B><form method='POST' action='#'><input type='submit' name='submit' value='Desactiver'><input type='text' name='nommatchs' hidden=false value='".$Match."'><input type='text' hidden=false name='Activer' value='0'> </form></td>";
			}
			else{
			echo"<td>$activation Match <B style='color:red'>no Activé</B><form method='POST' action='#'><input type='submit' name='submit' value='Activer'> <input type='text' hidden=false name='nommatchs' value='".$Match."'><input type='text' hidden=false name='Activer' value='1'></form></td>";
			}
			echo" </tr>";
}

echo "";
 echo"</tbody></table>";
$reponse->closeCursor();
}
catch(Exception $e)
{
    die('Erreur : '.$e->getMessage());
}
ECHO"";
}
?>
