<!DOCTYPE html>
<html lang="en">


<meta http-equiv="content-type" content="text/html;charset=utf-8" />

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Hotel VIP Praia | Want to visit paradise? Cape Verde is your destination, so come visit our islands. Situated in the coust of Africa, come on enjoy the sun and the fun! Travel to the perfect destination of tourism. Booking in hotels are always available.">
    <meta name="keywords" content="Cabo Verde, Visit Cabo Verde, Tourism Cabo Verde, Summer, Sun, Santiago Island, Beach, Kebra Kanela, Hotel VIP Praia, Excursions, Confort, Peace of Mind">
    <meta name="author" content="Prime Consulting">
    <title>Africa Games</title>
    <link rel="icon" href="images/favicon.ico">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic|Playfair+Display:400,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">

    <link href="css/owl.carousel.css" rel="stylesheet">
    <link href="css/owl.theme.css" rel="stylesheet">
    <link href="css/owl.transitions.css" rel="stylesheet">
    <link href="css/cs-select.css" rel="stylesheet">
    <link href="css/bootstrap-datepicker3.min.css" rel="stylesheet">
    <link href="css/freepik.hotels.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
		<script src="js/html5shiv.min.js"></script>
		<script src="js/respond.min.js"></script>
		<![endif]-->
    <script src="js/modernizr.custom.min.js"></script>

</head>

<body onunload="saveData( )">
    <div class="preloader"></div>
    <header class="header transp sticky">
        <!-- available class for header: .sticky .center-content .transp -->
        <nav class="navbar navbar-inverse" style="background-color: rgba(255, 255, 255, 0.9);">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
                    <a class="navbar-brand" href="#"><img src="images/logo.png" alt="logo" style="height: 70px"></a>
                </div>
                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="index-2.php">Home</a></li>
                        <li><a href="about.php">Qui sommes nous</a></li>
                        <!--<li><a href="promotions.html">Promoções</a></li>-->
                        <li class="active"><a href="paris.php">Paris sportif</a></li>
                        <li><a href="enplois.php">Offres d'emplois</a></li>
                        <li><a href="parteneriat.php">Parteneriat</a></li>
                        <li><a href="contact.php">Contacts</a></li>
                        <li>
                            <a>
                                <div id="google_translate_element"></div>
                            </a>
                        </li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </div>
            <!-- /.container-fluid -->
        </nav>
    </header>

    <img src="img/slides/paris2.png" alt="slide1">
  

    <div class="mg-about parallax">
			<div class="container">
				<div class="row">
					<div class="col-md-6">
                        <h2 class="mg-sec-left-title">PARIS SPORTIFS</h2>
						<p>PARIS SPORTIFS

Nous vous offrons la possibilité de parier sur vos sports préférés dans nos différents points de vente, par l’intermédiaire de nos partenaires et sur notre site internet.
</p>
<h2 class="mg-sec-left-title">ORGANISATION D’ÉVÈNEMENTS ET TOURNOIS SPORTIFS</h2>
                       <p>Pour les passionnés de compétitions et adeptes du jeu, CV Games proposera régulièrement des tournois de jeux vidéoainsi que des compétitions pour ses abonnés dès 2021. Ces compétions ainsi que leur règlement seront interne à l’entreprise. Quant aux passionnés de billard, des journées d’initiation seront organisées pour leur apprendre les meilleures techniques des pros.

</p>
<a href="#" class="btn btn-main">Click ici pour acceder a notre site de paris</a>
					</div>
					<div class="col-md-6">
						<div class="mg-gallery-container">
                        <li><img src="img/paris.png" alt="Recepcao"></li>
                        <li><img src="img/paris.png" alt="Recepcao"></li>
						</div>
					</div>
				</div>
			</div>
		</div>

        <footer class="mg-footer">
            <div class="mg-footer-widget" style="padding-top: 10px; padding-bottom: 10px;">
                <div class="container" style="margin-right: 0px;">
                    <div class="row">
                        <div class="col-md-4 col-md-offset-2 visible-lg">
                            <div class="widget" style="margin-bottom: 0px;">
                                <address style="margin-bottom: 0px;">
									<strong>Africa Games</strong><br>
									Av Jorge Barbosa Fazenda, <br>
									Praia, Cabo Verde
								</address>

                            </div>
                        </div>
                        <div class="col-md-4 visible-lg">
                            <div class="widget" style="margin-bottom: 0px;">
                                <strong>Contacts</strong><br>
                                <p style="margin-bottom: 0px;">
                                    Telephone: (+238) 930 25 98<br> Fax: (+238) 930 25 98<br> Email: info@africagames.biz
                                </p>

                            </div>
                        </div>
                        <!--
						<div class="col-md-4 visible-lg">
							<div class="widget" style="margin-bottom: 0px;">
								<strong>E-mail</strong><br>
								<p style="margin-bottom: 0px;">
									<a href="mailto:#">booking@hotelAfrica Games.cv</a>
								</p>
							</div>
						</div>
						-->
                        <div class="col-md-6 hidden-lg" style="width: 250px; margin-left: 70px;">
                            <div class="widget" style="margin-bottom: 0px;">
                                <address style="margin-bottom: 0px;">
									<strong>Africa Games</strong><br>
									Av Jorge Barbosa Quebra Canela, <br>
									Praia, Cabo Verde
								</address>
                            </div>
                        </div>
                        <div class="col-md-6 hidden-lg" style="width: 250px; margin-left: 70px;">
                            <div class="widget" style="margin-bottom: 0px;">
                                <strong>Contactos</strong><br>
                                <p style="margin-bottom: 0px;">
                                    Telefone: (+238) 930 25 98<br> Fax: (+238) 930 25 98<br> Email: info@africagames.biz<br>
                                    <!-- <a href="mailto:#">booking@hotelAfrica Games.cv</a> -->
                                </p>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mg-copyright">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12" style="text-align: center;">
                            <a href="https://guineeconnexion.net" target="_blank">Africa Games Design by Guinee Connexion © 2020</a>
                        </div>
                    </div>
                </div>
            </div>
        </footer>

        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery.min.js"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="js/bootstrap.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jssor.slider.mini.js"></script>
        <script src="js/classie.js"></script>
        <script src="js/selectFx.js"></script>
        <script src="js/bootstrap-datepicker.min.js"></script>
        <script src="js/starrr.min.js"></script>
        <script src="js/nivo-lightbox.min.js"></script>
        <script src="js/jquery.shuffle.min.js"></script>
        <!--<script src="js/gmaps.min.js"></script>-->
        <script src="js/jquery.parallax-1.1.3.js"></script>
        <script src="js/script.js"></script>

        <!-- Google analytics-->
        <script>
            (function(i, s, o, g, r, a, m) {
                i['GoogleAnalyticsObject'] = r;
                i[r] = i[r] || function() {
                    (i[r].q = i[r].q || []).push(arguments)
                }, i[r].l = 1 * new Date();
                a = s.createElement(o), m = s.getElementsByTagName(o)[0];
                a.async = 1;
                a.src = g;
                m.parentNode.insertBefore(a, m)
            })(window, document, 'script', '../www.google-analytics.com/analytics.js', 'ga');
            ga('create', 'UA-81807682-1', 'auto');
            ga('send', 'pageview');
        </script>

        <script>
            function googleTranslateElementInit() {
                new google.translate.TranslateElement({
                    pageLanguage: 'pt',
                    includedLanguages: 'ca,da,de,el,en,es,fr,it,ja,ko,nl,pl,pt,ru,sv,tl',
                    layout: google.translate.TranslateElement.InlineLayout.SIMPLE
                }, 'google_translate_element');
            };
        </script>
        <style type="text/css">
            div#google_translate_element div.goog-te-gadget-simple {
                background-color: transparent;
                border: transparent;
            }
            
            div#google_translate_element div.goog-te-gadget-simple a.goog-te-menu-value span {
                color: #555
            }
        </style>
        <script type="text/javascript" src="../translate.google.com/translate_a/elementa0d8.html?cb=googleTranslateElementInit"></script>

        <!-- tripadvisor -->
        <script src="https://www.jscache.com/wejs?wtype=selfserveprop&amp;uniq=960&amp;locationId=7315140&amp;lang=en_US&amp;rating=true&amp;nreviews=5&amp;writereviewlink=true&amp;popIdx=false&amp;iswide=false&amp;border=false&amp;display_version=2"></script>

        <script>
            /* Send sotres the check-in and Check-out values to be use for autocompleting the reservation form on another page*/
            function store() {
                if (typeof(Storage) !== "undefined") {
                    if (document.theform.widget_date.value != "" && document.theform.widget_date_to.value != "") {
                        sessionStorage.setItem("check_in_session", document.theform.widget_date.value);
                        sessionStorage.setItem("check_out_session", document.theform.widget_date_to.value);
                    } else {
                        if (document.theform_s.widget_date_s.value != "" && document.theform_s.widget_date_to_s.value != "") {
                            sessionStorage.setItem("check_in_session", document.theform_s.widget_date_s.value);
                            sessionStorage.setItem("check_out_session", document.theform_s.widget_date_to_s.value);
                        }
                    }
                } else {
                    alert("Sorry! No Web Storage support..")
                }
            };
        </script>

</body>

</html>